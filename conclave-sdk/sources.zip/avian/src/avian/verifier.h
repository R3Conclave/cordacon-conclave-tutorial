
/* Copyright (c) 2008-2015, Avian Contributors

   Permission to use, copy, modify, and/or distribute this software
   for any purpose with or without fee is hereby granted, provided
   that the above copyright notice and this permission notice appear
   in all copies.

   There is NO WARRANTY for this software.  See license.txt for
   details. */

#ifndef AVIAN_VERIFIER_H
#define AVIAN_VERIFIER_H

#include "avian/machine.h"

namespace vm {
  namespace verifier {

    /**
     * Verifies the Java class given by argument class_ against security exploits. If the class does not pass the
     * verifier checks then the function returns false and a description of the problem will be written in the input buffer.
     */
    jboolean verify_class(JNIEnv *env, jclass class_, char *buffer, jint buffer_size);

  } // namespace verifier {
} // namspace vm {

#endif


