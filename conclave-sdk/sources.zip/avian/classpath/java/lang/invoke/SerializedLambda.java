/* Copyright (c) 2008-2016, Avian Contributors

   Permission to use, copy, modify, and/or distribute this software
   for any purpose with or without fee is hereby granted, provided
   that the above copyright notice and this permission notice appear
   in all copies.

   There is NO WARRANTY for this software.  See license.txt for
   details. */

package java.lang.invoke;

public class SerializedLambda implements java.io.Serializable {
  public Object getCapturedArg(int i) {
    // todo
    return null;
  }

  public int getImplMethodKind() {
    // todo
    return 0;
  }

  public String getImplClass() {
    // todo
    return null;
  }

  public String getImplMethodName() {
    // todo
    return null;
  }

  public String getImplMethodSignature() {
    // todo
    return null;
  }

  public String getFunctionalInterfaceClass() {
    // todo
    return null;
  }

  public String getFunctionalInterfaceMethodName() {
    // todo
    return null;
  }

  public String getFunctionalInterfaceMethodSignature() {
    // todo
    return null;
  }
}
